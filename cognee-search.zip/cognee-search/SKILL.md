---
name: cognee-search
description: Optimize Cognee knowledge graph search operations. Use this skill when working with Cognee search queries, selecting appropriate search types, troubleshooting search issues, or optimizing search parameters for knowledge graph retrieval.
---

# Cognee Search Optimization

## Overview

Optimize search operations against Cognee knowledge graphs. This skill provides guidance on selecting the appropriate search type, formulating effective queries, tuning parameters, and troubleshooting common search issues.

## When to Use This Skill

Use this skill when:
- Selecting the appropriate Cognee search type for a query
- Formulating effective search queries for knowledge graphs
- Troubleshooting "context does not contain information" errors
- Optimizing search performance and relevance
- Working with domain-specific search patterns (e.g., veterinary, medical, legal)
- Implementing search in Python, HTTP API, or MCP contexts

## Search Type Selection

### Available Search Types

| Search Type | Best For | Output | Speed |
|-------------|----------|--------|-------|
| `GRAPH_COMPLETION` (default) | Complex questions needing relationships | LLM answer + graph context | Slower, most intelligent |
| `RAG_COMPLETION` | Fast text-only Q&A | LLM answer from chunks | Medium speed |
| `CHUNKS` | Raw passage retrieval | Chunk objects with metadata | Fastest |
| `SUMMARIES` | High-signal concise hits | Summary objects | Fast |
| `GRAPH_SUMMARY_COMPLETION` | Summary-first graph answers | Concise answer + context | Medium |
| `GRAPH_COMPLETION_COT` | Complex multi-step reasoning | Refined answer via reasoning | Slower |
| `GRAPH_COMPLETION_CONTEXT_EXTENSION` | Open-ended exploration | Expanded subgraph answer | Slower |
| `CYPHER` | Structured graph queries | Raw query results | Variable |
| `NATURAL_LANGUAGE` | Natural language to Cypher | Graph query results | Variable |
| `FEELING_LUCKY` | Uncertain which mode fits | Auto-selected mode results | Variable |
| `CHUNKS_LEXICAL` | Exact-term matching | Ranked text chunks | Fast |
| `TEMPORAL` | Time-based queries | Time-filtered results | Medium |
| `CODING_RULES` | Code-related knowledge | Structured code info | Medium |

### Decision Tree

```
Need structured graph data?
├── Yes → CYPHER (write query) or GRAPH_COMPLETION (natural language)
└── No → Need relationships?
    ├── Yes → GRAPH_COMPLETION or GRAPH_SUMMARY_COMPLETION
    └── No → Need raw text?
        ├── Yes → CHUNKS
        └── No → Need summaries?
            ├── Yes → SUMMARIES
            └── No → RAG_COMPLETION
```

### Search Type Details

#### GRAPH_COMPLETION (Recommended Default)
Natural language Q&A using full graph context and LLM reasoning.

```python
result = await cognee.search(
    query_text="What are the relationships between prednisolone and IBD in cats?",
    query_type=SearchType.GRAPH_COMPLETION,
    top_k=10
)
```

**Best for:** Complex questions, analysis, summaries, insights requiring understanding of entity relationships.

#### RAG_COMPLETION
Traditional RAG using document chunks without graph structure.

```python
result = await cognee.search(
    query_text="What are the side effects of xylazine?",
    query_type=SearchType.RAG_COMPLETION,
    top_k=5
)
```

**Best for:** Direct document retrieval, specific fact-finding, faster responses.

#### CHUNKS
Raw text segments that match the query semantically.

```python
chunks = await cognee.search(
    query_text="feline pancreatitis symptoms",
    query_type=SearchType.CHUNKS,
    top_k=10
)
```

**Best for:** Finding specific passages, citations, exact content, verifying data exists.

#### SUMMARIES
Pre-generated hierarchical summaries of content.

```python
summaries = await cognee.search(
    query_text="treatment protocols",
    query_type=SearchType.SUMMARIES,
    top_k=5
)
```

**Best for:** Quick overviews, document abstracts, topic summaries.

#### GRAPH_COMPLETION_COT (Chain-of-Thought)
Complex multi-step reasoning with refined answers.

```python
result = await cognee.search(
    query_text="What differential diagnoses should be considered for a cat with chronic vomiting?",
    query_type=SearchType.GRAPH_COMPLETION_COT,
    top_k=10
)
```

**Best for:** Complex reasoning, differential diagnoses, multi-step analysis.

#### CYPHER
Direct graph database queries using Cypher syntax.

```python
result = await cognee.search(
    query_text="MATCH (n:Entity)-[r]->(m:Entity) WHERE n.name CONTAINS 'xylazine' RETURN n, r, m LIMIT 10",
    query_type=SearchType.CYPHER
)
```

**Best for:** Advanced users, specific graph traversals, debugging.

#### FEELING_LUCKY
Intelligently selects and runs the most appropriate search type.

```python
result = await cognee.search(
    query_text="What sedatives are used for equine dentistry?",
    query_type=SearchType.FEELING_LUCKY
)
```

**Best for:** General-purpose queries when unsure which search type to use.

## Query Formulation Best Practices

### 1. Be Specific with Domain Terms

```python
# Poor - too vague
query = "What about IBD?"

# Better - specific and contextual
query = "What are the treatment options for inflammatory bowel disease in cats, including medications and dietary management?"
```

### 2. Include Key Entities

```python
# Include specific entities that exist in your knowledge graph
query = "What is the relationship between prednisolone dosing and inflammatory bowel disease in feline patients?"
```

### 3. Use Multiple Search Types for Complex Queries

```python
# Start with CHUNKS to verify content exists
chunks = await cognee.search(query, query_type=SearchType.CHUNKS, top_k=5)

# Then use GRAPH_COMPLETION for synthesized answer
answer = await cognee.search(query, query_type=SearchType.GRAPH_COMPLETION)
```

### 4. Scope to Specific Datasets

```python
# When access control is enabled, scope searches
result = await cognee.search(
    query_text="What are the dosing protocols for equine sedatives?",
    datasets=["veterinary"],
    query_type=SearchType.GRAPH_COMPLETION
)
```

## Parameter Optimization

### top_k Tuning

```python
# For broad exploration
result = await cognee.search(query, top_k=20)

# For focused, precise answers
result = await cognee.search(query, top_k=3)
```

**Guidelines:**
- Start with `top_k=10` (default)
- Lower values (3-5): Faster, more focused results
- Higher values (10-20): More comprehensive, but slower

### Custom System Prompts

```python
# Domain-specific prompting
result = await cognee.search(
    query_text="What are the contraindications for xylazine in horses?",
    system_prompt="""You are a veterinary medicine expert. Answer based strictly on the provided context.
    Include specific dosages, contraindications, and species-specific considerations.
    If information is not in the context, state that clearly.""",
    query_type=SearchType.GRAPH_COMPLETION
)
```

### Context-Only Retrieval

```python
# Get context without LLM generation (faster, for display/processing)
context = await cognee.search(
    query_text="feline pancreatitis symptoms",
    only_context=True
)
```

### Session-Based Conversational Search

```python
# First query
await cognee.search(
    query_text="What sedatives are used for equine dentistry?",
    session_id="vet_consultation_1"
)

# Follow-up query with context
await cognee.search(
    query_text="What are the dosing differences between xylazine and detomidine?",
    session_id="vet_consultation_1"  # Remembers previous context
)
```

### Node Set Filtering

```python
# Filter to specific content types
result = await cognee.search(
    query_text="equine dental procedures",
    node_name=["equine"],  # Filter to equine-specific content
    query_type=SearchType.GRAPH_COMPLETION
)
```

## Troubleshooting Search Issues

### Problem: "Context does not contain information"

**Diagnosis Steps:**

1. Verify data was added: Check graph database for nodes
2. Verify cognify completed: Check pipeline status
3. Check vector embeddings: Try CHUNKS search

```python
# Diagnostic query sequence
# 1. Check if content exists via chunks
chunks = await cognee.search(query, query_type=SearchType.CHUNKS, top_k=10)
print(f"Found {len(chunks)} chunks")

# 2. Check graph relationships directly
from cognee.infrastructure.databases.graph import get_graph_engine
graph = await get_graph_engine()
results = await graph.query("MATCH (n:Entity) WHERE n.name CONTAINS 'keyword' RETURN n LIMIT 10")
```

**Solutions:**
- Run `cognify` if data was added but not processed
- Check dataset permissions if access control is enabled
- Verify the query terms match the ingested content

### Problem: Slow Searches

**Solutions:**
- Reduce `top_k` value
- Use `RAG_COMPLETION` instead of `GRAPH_COMPLETION`
- Scope to specific datasets
- Use `only_context=True` to skip LLM generation
- Enable caching: `CACHING=true` in `.env`

### Problem: Irrelevant Results

**Solutions:**
- Improve query specificity
- Add domain terms
- Use custom system prompt
- Filter by node sets: `node_name=["specific_content"]`
- Verify cognify extracted relevant entities

### Problem: Empty Knowledge Graph

```python
# Check if graph is empty
from cognee.infrastructure.databases.graph import get_graph_engine
graph = await get_graph_engine()
is_empty = await graph.is_empty()
```

**Solution:** Run `cognify` to process added data into the knowledge graph.

## API Usage Examples

### Python API

```python
import asyncio
import cognee
from cognee.api.v1.search import SearchType

async def search_knowledge(query: str, search_type: SearchType = SearchType.GRAPH_COMPLETION):
    """Optimized search for knowledge graph."""
    return await cognee.search(
        query_text=query,
        query_type=search_type,
        datasets=["specific_dataset"],  # Scope for speed
        top_k=10,
        save_interaction=True  # For audit trail
    )

# Usage
result = await search_knowledge("What are the contraindications for detomidine?")
```

### HTTP API (curl)

```bash
# GRAPH_COMPLETION search
curl -X POST "http://localhost:8000/api/v1/search" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "What are the signs of pancreatitis in dogs?",
    "searchType": "GRAPH_COMPLETION",
    "datasets": ["veterinary"],
    "topK": 10
  }'

# CHUNKS search for verification
curl -X POST "http://localhost:8000/api/v1/search" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "pancreatitis canine symptoms",
    "searchType": "CHUNKS",
    "topK": 5
  }'
```

### MCP Tool

```python
# Using Cognee MCP
result = mcp__cognee__search(
    search_query="What are the dosing guidelines for equine sedatives?",
    search_type="GRAPH_COMPLETION",
    top_k=10
)
```

## Performance Tuning

### For Production Use

1. **Enable caching** in `.env`: `CACHING=true`
2. **Use session IDs** for conversational context
3. **Set appropriate rate limits**: `LLM_RATE_LIMIT_ENABLED=true`
4. **Monitor via telemetry** for query optimization

### For Large Datasets

1. Use dataset scoping: `datasets=["specific_dataset"]`
2. Reduce `top_k` for faster responses
3. Consider `RAG_COMPLETION` for simple queries
4. Use `SUMMARIES` for overview queries

## Resources

### references/

- `search_types.md` - Detailed documentation of all search types
- `query_patterns.md` - Domain-specific query patterns and templates

### Related Documentation

- Cognee Search Documentation: https://docs.cognee.ai/core-concepts/main-operations/search
- Cognee MCP Tools: https://docs.cognee.ai/cognee-mcp/mcp-tools
